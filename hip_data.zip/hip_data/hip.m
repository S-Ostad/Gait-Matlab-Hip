function RM = hip(X)
%% thigh segment
M_total = 70;
m_thigh = 0.1*M_total;
L_thigh = 0.5;
L_od1 = 0.567*L_thigh;
R_thigh = 0.323*L_thigh;
g = 9.81;
I_thigh = m_thigh*R_thigh^2;

ax_hip = X(:,1);       %% acceleration x
ay_hip = X(:,2);       %% acceleration y
teta_hip = X(:,3);
alpha_hip = X(:,4);    %% angular acceleration

Rx1 = m_thigh*ax_hip 
Ry1 = m_thigh*g + m_thigh*ay_hip
M1 = L_od1.*cos(teta_hip).*Ry1 + L_od1.*sin(teta_hip).*Rx1 + I_thigh*alpha_hip

RM = Rx1.^2 + Ry1.^2 + M1.^2;

end